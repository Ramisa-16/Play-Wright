import { test, expect } from '@playwright/test';
import Item from '../pages/item';

test('Add two items successfully', async ({ page }) => {
  try {
    console.log('Navigating to the user dashboard...');
    await page.goto('https://dailyfinance.roadtocareer.net/user');
    console.log('Navigated to the user dashboard.');

    const item = new Item(page);

    console.log('Adding the first item: Rice Bowl');
    await item.addItem('pencil', '15', '2024-12-12', 'Nice food');
    console.log('First item added successfully.');

    console.log('Adding the second item: Burger');
    await item.addItem('pen', '20', '2024-12-12', 'Delicious');
    console.log('Second item added successfully.');

    console.log('Validating that the items are visible on the page...');
    const riceBowlItem = await page.locator('text=Rice Bowl');
    await expect(riceBowlItem).toBeVisible();
    console.log('First item is visible on the page.');

    const burgerItem = await page.locator('text=Burger');
    await expect(burgerItem).toBeVisible();
    console.log('Second item is visible on the page.');

    console.log('Test completed successfully. All items are added and verified.');
  } catch (error) {
    console.error('Error during the add item test:', error);
    throw error;
  }
});