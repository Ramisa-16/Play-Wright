import { test, expect } from '@playwright/test';
import Profile from '../pages/profile';

test('User uploads a profile photo and saves changes', async ({ page }) => {
  try {
    console.log('Navigating to profile settings page...');
    const profile = new Profile(page);
    await profile.goToProfileSettings();
    console.log('Navigated to profile settings page.');

    const photoPath = 'path/to/profile-picture.jpg'; 
    console.log(`Uploading profile photo from path: ${photoPath}`);
    await profile.uploadProfilePhoto(photoPath);
    console.log('Profile photo uploaded successfully.');

    console.log('Saving profile changes...');
    await profile.saveProfileChanges();
    console.log('Profile changes saved successfully.');

    console.log('Verifying that the profile photo is uploaded...');
    await profile.assertProfilePhotoUploaded();
    console.log('Profile photo upload verified successfully.');

    console.log('Test completed successfully.');
  } catch (error) {
    console.error('Error during the profile photo upload test:', error);
    throw error;
  }
});
