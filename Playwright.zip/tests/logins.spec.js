import { test, expect } from '@playwright/test';
import Login from '../pages/login';

test('Login is successful and login data is saved', async ({ page }) => {
  try {
    console.log('Navigating to the website...');
    await page.goto('https://dailyfinance.roadtocareer.net');
    console.log('Navigated to the homepage.');

    const login = new Login(page);

    console.log('Filling in login credentials...');
    await login.fillEmailAddress('user@example.com'); 
    await login.fillPassword('SecurePassword123'); 

    console.log('Submitting login form...');
    await login.submitLogin();

    console.log('Saving login data to file...');
    await login.saveLoginData();

    console.log('Login process completed successfully.');
  } catch (error) {
    console.error('Error during the login test:', error);
    throw error;
  }
});