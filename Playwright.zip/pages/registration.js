import fs from 'fs';

class Registration {
  constructor(page) {
    this.page = page;
    this.userData = {};
  }

  async navigateToRegister() {
    try {
      await this.page.getByRole('link', { name: 'Register' }).click();
      console.log('Navigated to registration page.');
    } catch (error) {
      console.error('Error navigating to registration page:', error);
    }
  }

  async fillField(label, value, fieldName) {
    try {
      await this.page.getByLabel(label).fill(value);
      this.userData[fieldName] = value;
      console.log(`${fieldName} filled: ${value}`);
    } catch (error) {
      console.error(`Error filling ${fieldName}:`, error);
    }
  }

  async selectGender() {
    try {
      await this.page.getByRole('radio').first().check();
      this.userData.gender = 'Selected';
      console.log('Gender selected.');
    } catch (error) {
      console.error('Error selecting gender:', error);
    }
  }

  async checkCheckbox() {
    try {
      await this.page.getByRole('checkbox').check();
      console.log('Checkbox checked.');
    } catch (error) {
      console.error('Error checking checkbox:', error);
    }
  }

  async submitRegistration() {
    try {
      await this.page.getByRole('button', { name: 'Register' }).click();
      console.log('Registration form submitted.');
    } catch (error) {
      console.error('Error submitting registration form:', error);
    }
  }

  saveUserData() {
    try {
      fs.writeFileSync('userData.json', JSON.stringify(this.userData, null, 2), 'utf-8');
      console.log('User data saved to userData.json');
    } catch (error) {
      console.error('Error saving user data:', error);
    }
  }

  async registerUser() {
    await this.navigateToRegister();
    await this.fillField('First Name *', 'Ramisa Sharar', 'firstName');
    await this.fillField('Last Name', 'Nidhi', 'lastName');
    await this.fillField('Email *', 'ramisashararnidhi377@gmail.com', 'email');
    await this.fillField('Password *', 'SecurePass123', 'password');
    await this.fillField('Phone Number *', '01234567890', 'phoneNumber');
    await this.fillField('Address', '123 B block, Aftabnogor', 'address');
    await this.selectGender();
    await this.checkCheckbox();
    await this.submitRegistration();
    this.saveUserData();
  }
}

export default Registration;
