import fs from 'fs';

class Item {
  constructor(page) {
    this.page = page;
    this.itemData = {};
  }

  async navigateToAddItem() {
    try {
      await this.page.getByRole('button', { name: 'Add Cost' }).click();
      console.log('Navigated to Add Item page.');
    } catch (error) {
      console.error('Error navigating to Add Item page:', error);
    }
  }

  async fillField(label, value, fieldName) {
    try {
      await this.page.getByLabel(label).fill(value);
      this.itemData[fieldName] = value;
      console.log(`${fieldName} filled: ${value}`);
    } catch (error) {
      console.error(`Error filling ${fieldName}:`, error);
    }
  }

  async incrementItemQuantity() {
    try {
      await this.page.locator('div').filter({ hasText: /^-\+$/ }).getByRole('spinbutton').click();
      await this.page.getByRole('button', { name: '+' }).click();
      console.log('Item quantity incremented.');
    } catch (error) {
      console.error('Error incrementing item quantity:', error);
    }
  }

  async handleDialog() {
    this.page.once('dialog', (dialog) => {
      console.log(`Dialog message: ${dialog.message()}`);
      dialog.dismiss().catch(() => {});
    });
  }

  async submitItem() {
    try {
      await this.page.getByRole('button', { name: 'Submit' }).click();
      console.log('Item submission triggered.');
    } catch (error) {
      console.error('Error submitting item:', error);
    }
  }

  saveItemData() {
    try {
      fs.writeFileSync('itemData.json', JSON.stringify(this.itemData, null, 2), 'utf-8');
      console.log('Item data saved to itemData.json');
    } catch (error) {
      console.error('Error saving item data:', error);
    }
  }

  async addItem(itemName, amount, purchaseDate, remarks) {
    await this.navigateToAddItem();
    await this.fillField('Item Name', itemName, 'itemName');
    await this.incrementItemQuantity();
    await this.fillField('Amount', amount, 'amount');
    await this.fillField('Purchase Date', purchaseDate, 'purchaseDate');
    await this.fillField('Remarks', remarks, 'remarks');
    await this.handleDialog();
    await this.submitItem();
    this.saveItemData();
  }
}

export default Item;
