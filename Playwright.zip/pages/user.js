import fs from 'fs';

class Profile {
  constructor(page) {
    this.page = page;
  }

  async goToProfileSettings() {
    try {
      await this.page.goto('https://dailyfinance.roadtocareer.net/user');
      console.log('Navigated to profile settings.');
    } catch (error) {
      console.error('Error navigating to profile settings:', error);
    }
  }

  async uploadProfilePhoto(photoPath) {
    try {
      const fileInput = this.page.locator('input[type="../resource/picture"]');
      await fileInput.setInputFiles(photoPath);
      console.log('Profile photo uploaded.');
    } catch (error) {
      console.error('Error uploading profile photo:', error);
    }
  }

  async saveProfileChanges() {
    try {
      await this.page.getByRole('button', { name: 'UPDATE' }).click();
      console.log('Profile changes saved.');
    } catch (error) {
      console.error('Error saving profile changes:', error);
    }
  }

  async updateProfile(photoPath) {
    await this.goToProfileSettings();
    await this.uploadProfilePhoto(photoPath);
    await this.saveProfileChanges();
  }
}

export default Profile;
