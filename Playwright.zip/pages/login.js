import fs from 'fs';

class Login {
  constructor(page) {
    this.page = page;
    this.loginData = {};
  }

  async navigateToLogin() {
    try {
      await this.page.getByRole('link', { name: 'Login' }).click();
      console.log('Navigated to login page.');
    } catch (error) {
      console.error('Error navigating to login page:', error);
    }
  }

  async fillField(label, value, fieldName) {
    try {
      await this.page.getByLabel(label).fill(value);
      this.loginData[fieldName] = value;
      console.log(`${fieldName} filled: ${value}`);
    } catch (error) {
      console.error(`Error filling ${fieldName}:`, error);
    }
  }

  async submitLogin() {
    try {
      await this.page.getByRole('button', { name: 'Login' }).click();
      console.log('Login form submitted.');
    } catch (error) {
      console.error('Error submitting login form:', error);
    }
  }

  saveLoginData() {
    try {
      fs.writeFileSync('loginData.json', JSON.stringify(this.loginData, null, 2), 'utf-8');
      console.log('Login data saved to loginData.json');
    } catch (error) {
      console.error('Error saving login data:', error);
    }
  }

  async loginUser(email, password) {
    await this.navigateToLogin();
    await this.fillField('Email *', email, 'email');
    await this.fillField('Password *', password, 'password');
    await this.submitLogin();
    this.saveLoginData();
  }
}

export default Login;
